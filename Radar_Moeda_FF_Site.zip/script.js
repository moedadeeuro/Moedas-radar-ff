
const messages = [
    "“Se não tem gelo, tem cabeça — pensa antes do rush.”",
    "“Confia no movimento, mas nunca se expõe.”",
    "“A próxima safe vai ser sua zona de domínio.”",
    "“Não se esqueça da sua cover. Estratégia é tudo.”"
];

let currentMessage = 0;

function nextMessage() {
    currentMessage = (currentMessage + 1) % messages.length;
    document.getElementById("coach-message").textContent = messages[currentMessage];
}

function addMemory() {
    const list = document.getElementById("safe-memory-list");
    const newItem = document.createElement("li");
    newItem.textContent = "Safe antiga: Factory";
    list.appendChild(newItem);
}
